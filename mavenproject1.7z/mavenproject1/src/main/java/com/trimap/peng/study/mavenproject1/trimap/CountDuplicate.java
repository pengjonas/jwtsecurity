/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1.trimap;

import java.util.Arrays;
import java.util.List;
import java.util.logging.*;

/**
 *
 * @author Peng
 */
public class CountDuplicate {
    private Logger log = Logger.getLogger(getClass().toString());
    private int[] s1 = new int[]{2,34,1, 31,22,98,97};
    private int[] s2 = new int[]{2,30, 1,9, 31,22,98,97,98};
    private List<String> s3 = Arrays.asList("1", "3");
    public int find(int[] sorted, int value) {
        for (int i = 0; i < sorted.length; i++) {
            if (sorted[i] > value) {
                return i;
            }
        }
        return 0;
    }
    public void count() {
        Arrays.sort(s2);
        log.info(Arrays.toString(s2));
        int[] result = new int[s1.length];
        for (int i = 0; i < s1.length; i++) {
             result[i] = this.find(s2, s1[i]);
        }
        log.info(Arrays.toString(result));
    }
    public static void  main(String[] args) {
        CountDuplicate cd = new CountDuplicate();
        cd.count();
    }
}