/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1.trimap;

import java.util.Arrays;
import java.util.List;

/**
 *
 * @author Peng
 */
public class FindTwoElements {
    
    public int[] arr;
    
    public FindTwoElements() {
        arr = new int[98];
        int j = 0;
        for (int i = 0; i < 100; i++) {
            if (i == 56 || i == 78) continue;
            arr[j++] = i+1;
        }
    }
    
    public String[] array(List<String> list) {
        String[] s = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            s[i] = list.get(i);
        }
        return s;
    }
    
    
    
    
    
    public static void main(String args[]) {
        FindTwoElements ft = new FindTwoElements();
        System.out.println(Arrays.toString(ft.arr));
        System.out.println(Arrays.toString(ft.array(Arrays.asList("3", "5", "6"))));
     
    }
    
}
