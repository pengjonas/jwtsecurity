/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1.trimap;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Logger;


/**
 *
 * @author Peng
 */
public class MyStack {
    private Logger log = Logger.getLogger(getClass().toString());
    private List<String> stack = new ArrayList();
    
    public void push(String s) {
        stack.add(s);
        
    }
    public String pop() {
        if (stack.isEmpty()) return null;
        String s = stack.get(stack.size() - 1);
        stack.remove(stack.size() - 1);
        return s;
    }
    public static void main(String[] args) {
        MyStack stack = new MyStack();
        stack.push("1");
        stack.push("2");
        stack.push("3");
        stack.log.info(stack.pop());
        stack.log.info(stack.pop());
        stack.log.info(stack.pop());
        stack.log.info(stack.pop());
        stack.log.info(stack.pop());
        int[] arr = new int[]{1,2,3};
        stack.log.info(Arrays.toString(arr));
    }
}
