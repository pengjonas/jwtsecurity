/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1.trimap;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Stack;
import java.util.Queue;

/**
 *
 * @author Peng
 */
public class StackAndQueue {
    private Stack<Character> stack = new Stack();
    


    private LinkedList queue = new LinkedList();
    private Queue<Integer> q = new LinkedList<Integer>();
    
    
    public void pushCharacter(char ch) {
        this.stack.push(new Character(ch));
        this.q.de
    }
    
    
    
    public void enqueueCharacter(char ch) {
        this.queue.push(String.valueOf(ch));
    }
    public char popCharacter() {
        return this.stack.pop();
    }
    public char dequeueCharacter() {
        return this.queue.pop().toCharArray()[0];
    }
    public static void main(String[] args) {
        StackAndQueue sq = new StackAndQueue();
        sq.pushCharacter('c');
        sq.enqueueCharacter('d');
        System.out.println(sq.dequeueCharacter());
        System.out.println(sq.popCharacter());
        
        int[] a = new int[]{3,2,1};
                int current = 0;
        int times = 0;
        for (int i = current; i < a.length; i++) {
            for (int j = i + 1; j < a.length; j++) {
                if (a[j] < a[current]) {
                    int tmp = a[current];
                    a[current] = a[j];
                    a[j] = tmp;
                    times++;
                }
            }
        }
    }
}
