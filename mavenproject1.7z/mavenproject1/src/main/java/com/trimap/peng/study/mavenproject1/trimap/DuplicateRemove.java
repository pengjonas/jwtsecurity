/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1.trimap;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import java.util.logging.Logger;
import static java.util.stream.Collectors.toList;

/**
 *
 * @author Peng
 */
public class DuplicateRemove implements Runnable {
    private Logger logger = Logger.getLogger(getClass().toString());

    private int[] sorted;
    public DuplicateRemove() {
        this.sorted = new int[]{1,2,2,2,3,5,5,8,8,10,10,10,23,58,91,91};
    }

    @Override
    public void run() {
        List<Integer> list = Arrays.asList(1,2,3,3,5,5,5,10,21,21,99,99,99,100);
        Comparator<Integer> comparator = (t1,t2) -> {return t1-t2;};
        int min = list.stream().min( comparator ).get() - 1;
        int[] mins = new int[]{min};
        logger.info(String.valueOf(min));
        List<Integer> newList = list.stream().filter(new Predicate<Integer>() {
            @Override
            public boolean test(Integer t) {
                if (t > mins[0]) {
                    mins[0] = t;return true;
                } else {
                    return false;
                }
            }
        })
                .collect(toList());
        logger.info(newList.toString());
        int j = this.sorted.length;
        int newIdx = 0;
        int minimum = this.sorted[0] - 1;
        for (int i = 0; i < j; i++) {
            if (this.sorted[i] > minimum) {
                this.sorted[newIdx++] = this.sorted[i];                
                minimum = this.sorted[i];
            } 
        }
        logger.info(Arrays.toString(Arrays.copyOf(this.sorted, newIdx)));
        
    }
    
    public static void main(String aregs[]) {
        DuplicateRemove duplicateRemove = new DuplicateRemove();
        duplicateRemove.logger.info(Arrays.toString(duplicateRemove.sorted));
        duplicateRemove.run();
    }
    
}
