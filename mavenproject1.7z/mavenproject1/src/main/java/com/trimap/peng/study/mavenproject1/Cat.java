/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1;

/**
 *
 * @author Peng
 */
public class Cat extends Animal{
    public void eat() {
        System.out.println("Cat Eat");
    }
    public void eat(String food) {
        System.out.println("Cat Eat " + food);
    }
    public static void sleep() {
        System.out.println("Cat Sleep");
    }

    public static void main(String args[]) {
        Animal cat = new Cat();
        cat.eat();//Overriding: which method is called is resolved at runtime, so it's runtime polymorphism
//        cat.eat("fish"); //error
        cat.sleep();
        cat.run();
        Cat cat1 = new Cat();
        cat1.eat();
        cat1.eat("fish");//Overloading
    }
}
