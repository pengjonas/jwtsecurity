/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1.trimap;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Peng
 */
public class QuickSort implements Runnable {
    private int[] s = new int[]{2, 10, 9, 8, 7,22, -1, 13, 15, 0, 99, 57};

    @Override
    public void run() {
        
    }
    public void sort(int[] s, int i, int j) {
        int sortIndex = i;
        for (int k = i; k < j; k++) {
            if (s[k] < s[j]) {
                int temp = s[sortIndex];
                s[sortIndex] = s[k];
                s[k] = temp;
                sortIndex++;
            }
        }
        int temp = s[sortIndex];
        s[sortIndex] = s[j];
        s[j] = temp;
        if (sortIndex-1>0) sort(s, 0, sortIndex - 1);
        if (j> sortIndex+1) sort(s, sortIndex+1, j);
        
    }
    
    public static void main(String args[]) {
        QuickSort qs = new QuickSort();
        int[] s = new int[]{2, 10, 9, 8,101,60, 7,22, -1, 13, 15, 0, 99, 57};
        System.out.println(Arrays.toString(s));
        qs.sort(s, 0, s.length-1);
        System.out.println(Arrays.toString(s));
        String s2;
        try {
            s2 = new SimpleDateFormat("d M y").parse("9 6 2015").toString();
        System.out.println(s2);
        } catch (ParseException ex) {
            Logger.getLogger(QuickSort.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
   
    
}
