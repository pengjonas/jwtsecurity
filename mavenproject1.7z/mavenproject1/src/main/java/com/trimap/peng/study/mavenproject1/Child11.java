/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1;

/**
 *
 * @author Peng
 */
public class Child11 extends Child1{

    public String name = "child11";
    public void go1() {
        System.out.println("child11 g1");
    }
    public void go2() {
        System.out.println("child11 g2");
    }
    public void go3() {
        System.out.println("child11 g3");
    }
 
    
}
