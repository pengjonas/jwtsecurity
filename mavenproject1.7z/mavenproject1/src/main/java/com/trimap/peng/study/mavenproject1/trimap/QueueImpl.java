/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1.trimap;

import java.util.ArrayList;
import java.util.Timer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Peng
 */
public class QueueImpl implements Queue {

    private ArrayList<String> list = new ArrayList();
    @Override
    public void push(String s) {
        list.add(s);
        
    }

    public int getSize() {
        return list.size();
    }
    @Override
    public String pop() {
            String s = list.get(0);
            list.remove(0);
            return s;
        
    }
    
    public static void main(String args[]) {
        Queue queue = new QueueImpl();
        Thread writer = new Thread(new Runnable() {
            @Override
            public void run() {
                int i = 0;
                for(;;) {
                    String s = String.valueOf(i++);
                    queue.push(s);
                    System.out.println("write:" + s);
                }
            }
        });
        Thread reader = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(QueueImpl.class.getName()).log(Level.SEVERE, null, ex);
                }
                for(;;) {
                    if (queue.getSize() > 0)
                        System.out.println("read:" + queue.pop());                    
                }
            }
        });
        writer.start();
        reader.start();
    }
    
    
}
