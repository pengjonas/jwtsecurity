/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1.trimap;

import java.util.Arrays;

/**
 *
 * @author Peng
 */
public class BinaryFind {
    
    public int find(int[] arr, int i) {        
        int startIdx = 0;
        int endIdx = arr.length - 1;
        if (endIdx == 0) {
            if (arr[endIdx] == i)
                return arr[endIdx];
            else return -1;
        }
        if (arr[(endIdx + startIdx) / 2] == i) {
            return arr[(endIdx + startIdx) / 2];
        }
        else if (arr[(endIdx + startIdx) / 2] > i) {
            startIdx = 0;
            endIdx = (endIdx + startIdx) / 2 ;
            return find(Arrays.copyOfRange(arr, startIdx, endIdx), i);
        }
        else {
            startIdx = (endIdx + startIdx) / 2 + 1 ;
            return find(Arrays.copyOfRange(arr, startIdx, endIdx+1), i);
        }
    }
    
    public static void main(String args[]) {
        int[] arr = new int[]{3,2,10,23,3,456,46,21,98,98,98};
        Arrays.sort(arr);
        BinaryFind bf = new BinaryFind();
        System.out.println(bf.find(arr, 2));
        
        int n = 439;
        String s = Integer.toBinaryString(n);
        char[] c = s.toCharArray();
        int r = 0;
        int max = 0;
        for (int i = 0; i < c.length; i++) {
            if (c[i] == '0') {                
                if (r > max) {
                    max = r;
                }
                r = 0;
            }
            else {
                r++;
            }
        }
        if (r > max) max = r;
        System.out.println(max);
    }
    
    
}
