/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1.trimap;

import org.apache.commons.lang.StringUtils;

/**
 *
 * @author Peng
 */
public class ReverseString {
    public static void main(String args[]) {
        String s = "abcd abcdaeec asdf";
        String s1 = "cdae5";
        int i = 0;
        for(i = 0; i < s.length() - s1.length() + 1; i++) {
            if(s1.equals(s.substring(i, i+s1.length())))
                System.out.println(i);
        }
        if (i == s.length() - s1.length() + 1) {
            System.out.println("N/A");
        }
        
        String before = "asdf asdf q2334";
        System.out.println(new StringBuffer(before).reverse());
        String[] after = new String[before.split(" ").length];
        for ( int j = 0; j < before.split(" ").length; j++) {
            after[j] = new StringBuffer(before.split(" ")[j]).reverse().toString();
        }
        System.out.println(StringUtils.join(after," "));
        
    }
}
