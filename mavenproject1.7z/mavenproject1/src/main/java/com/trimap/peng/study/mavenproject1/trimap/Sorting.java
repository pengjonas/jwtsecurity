/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1.trimap;

import java.util.Arrays;
import java.util.logging.Logger;
import sun.rmi.runtime.Log;

/**
 *
 * @author Peng
 */
public class Sorting {
    
 
    private Logger logger = Logger.getLogger(getClass().toString());
    

    public int[] tobeSorted ;
    public String test;

    public Sorting() {
        this.tobeSorted = new int[]{2,3,8,1,0,9,12,4,78,21};
    }

    public void sort() {
        int i = 0;
        int j = tobeSorted.length - 1;
        while (j > 0) {
            i = 0;
            while (i < j) {
                if (tobeSorted[i] < tobeSorted[j]) {
                    int temp = tobeSorted[i];
                    tobeSorted[i] = tobeSorted[j];
                    tobeSorted[j] = temp;
                }
                i++;
            }
            j--;
        }
    }

    public static void main(String[] args) {
        Sorting sorting = new Sorting();
        System.out.println(Arrays.toString(sorting.tobeSorted));
        sorting.sort();
        System.out.println(Arrays.toString(sorting.tobeSorted));
        
        int[] s = {1,2,3,19,0,-2,34,38,12,39};
        sorting.logger.info(Arrays.toString(s));
    }

}
