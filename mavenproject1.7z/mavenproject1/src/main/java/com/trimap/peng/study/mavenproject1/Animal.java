/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1;

/**
 *
 * @author Peng
 */
public class Animal {
    
    public void eat() {
        System.out.println("Animal Eat");
    }
    public static void sleep() {
        System.out.println("Animal Sleep");
    }
    public void run() {
        System.out.println("Animal Run");
    }
    
}
