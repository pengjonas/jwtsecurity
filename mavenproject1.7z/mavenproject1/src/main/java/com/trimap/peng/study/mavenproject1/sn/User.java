/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1.sn;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Peng
 */
public class User {
    private long userId;
    private String fistName;
    private String lastName;
    
    private List<User> friends = new ArrayList();

    public User(long userId, String fistName, String lastName) {
        this.userId = userId;
        this.fistName = fistName;
        this.lastName = lastName;
    }   
    
    public String getFistName() {
        return fistName;
    }

    public void setFistName(String fistName) {
        this.fistName = fistName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public List<User> getFriends() {
        return friends;
    }

    public void setFriends(List<User> friends) {
        this.friends = friends;
    }
    
    public void addFriend(User friend) {
        this.friends.add(friend);
    }
    public void removeFriend(User friend) {
        this.friends.remove(friend);
    }
        
    
    
    
    
    
    
}
