/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.IntSupplier;
import java.util.regex.Pattern;
import java.util.stream.IntStream;
import org.apache.commons.lang.StringUtils;

/**
 *
 * @author Peng
 */
public class Java8Tester1 {

    private List<Transaction> transactions;

    public Java8Tester1() {
        this.init();
    }

    protected void init() {
        Trader raoul = new Trader("Raoul", "Cambridge");
        Trader mario = new Trader("Mario", "Milan");
        Trader alan = new Trader("Alan", "Cambridge");
        Trader brian = new Trader("Brian", "Cambridge");

        this.transactions = Arrays.asList(
                new Transaction(brian, 2011, 300),
                new Transaction(raoul, 2012, 1000),
                new Transaction(raoul, 2011, 400),
                new Transaction(mario, 2012, 710),
                new Transaction(mario, 2012, 700),
                new Transaction(alan, 2012, 950)
        );
    }
    
    private void process(ParentInterface p) {
        p.go2();
        
    }
    enum TrafficLight {
       RED(30), AMBER(10), GREEN(30);  // Named constants

       private final int seconds;      // Private variable

       TrafficLight(int seconds) {     // Constructor
          this.seconds = seconds;
       }

       int getSeconds() {              // Getter
          return seconds;
       }
    }
 

    public static void main(String args[]) {
        Java8Tester1 tester = new Java8Tester1();
        
        tester.transactions.get(0).getTrader().toString();

        //Find all transactions in the year 2011 and sort them by value (small to high).
        tester.transactions.stream().filter(t -> t.getYear() == 2011).sorted((t1, t2) -> Integer.compare(t1.getValue(), t2.getValue())).forEach(t -> System.out.println(t.toString()));

        //What are all the unique cities where the traders work?
        System.out.println();
        tester.transactions.stream().map(Transaction::getTrader).map(Trader::getCity).distinct().forEach(t -> System.out.println(t.toString()));

        //Find all traders from Cambridge and sort them by name        
        System.out.println();
        tester.transactions.stream().map(Transaction::getTrader).filter(t -> t.getCity() == "Cambridge").map(Trader::getName).distinct().sorted(String::compareTo).forEach(t -> System.out.println(t.toString()));

        //Return a string of all traders’ names sorted alphabetically.
        System.out.println();
        tester.transactions.stream().map(Transaction::getTrader).map(Trader::getName).distinct().sorted(String::compareTo).forEach(t -> System.out.println(t.toString()));

        //Are any traders based in Milan?
        System.out.println();
        System.out.println(tester.transactions.stream().map(Transaction::getTrader).anyMatch(t -> t.getCity() == "Milan"));

        //Print all transactions’ values from the traders living in Cambridge.
        System.out.println();
        tester.transactions.stream().filter(t -> t.getTrader().getCity() == "Cambridge").forEach(t -> System.out.println(t.getValue()));

        //What’s the highest value of all the transactions?
        System.out.println();
        Optional<Transaction> optional = tester.transactions.stream().max((t1, t2) -> Integer.compare(t1.getValue(), (t2.getValue())));
        optional.ifPresent(t -> System.out.println(t.getValue()));

        //Find the transaction with the smallest value.
        System.out.println();
        Optional<Transaction> optional1 = tester.transactions.stream().min((t1, t2) -> Integer.compare(t1.getValue(), (t2.getValue())));
        optional1.ifPresent(t -> System.out.println(t.getValue()));

        System.out.println(tester.transactions.stream().map(Transaction::getValue).reduce(
                Integer::min
        ));

        System.out.println();
        System.out.println(tester.transactions.stream().mapToInt(Transaction::getValue).sum());
        tester.transactions.stream().mapToInt(Transaction::getValue).boxed();
        tester.transactions.stream().mapToInt(Transaction::getValue).max().orElse(1);
        IntStream intStream = tester.transactions.stream().mapToInt(Transaction::getValue);
        System.out.println(IntStream.range(1, 100).filter(n -> n % 2 == 0).count());

        IntSupplier fib = new IntSupplier() {
            private int previous = 0;
            private int current = 1;

            public int getAsInt() {
                int oldPrevious = this.previous;
                int nextValue = this.previous + this.current;
                this.previous = this.current;
                this.current = nextValue;
                return oldPrevious;
            }
        };
        
        IntStream.generate(fib).limit(10).forEach(System.out::println);
        
        Predicate<String> p = (String f) -> f.equalsIgnoreCase("languageCode");
        java.util.function.Predicate<String> nonInternational = (String t) -> {return t!=null && ( t.equalsIgnoreCase("CA") || t.equalsIgnoreCase("US"));};
        
        System.out.println(p.apply("languageCode"));
        
        Function<Double, String> DOLLAR_FORMAT = (Double d) -> {
            if (d == null) {
                return " 000000000.00";
            }            
            DecimalFormat df = new DecimalFormat("#.00");         
            if (d > 0) {
                String formated = df.format(d);
                return " " + StringUtils.leftPad(formated, 12, "0");
            }
            else if (d < 0) {
                String formated = df.format(Math.abs(d));
                return "-" + StringUtils.leftPad(formated, 12, "0");
            }
            else return " 000000000.00";
        };
         
         System.out.println(DOLLAR_FORMAT.apply(9.3423).toString());
         System.out.println(DOLLAR_FORMAT.apply(9.34653).toString());
         System.out.println(DOLLAR_FORMAT.apply(-9.3423).toString());
         System.out.println(DOLLAR_FORMAT.apply(-9.3993).toString());
         System.out.println(DOLLAR_FORMAT.apply(-0.3993).toString());
         System.out.println(DOLLAR_FORMAT.apply(0.3293).toString());
         System.out.println(DOLLAR_FORMAT.apply(0.3233).toString());
         System.out.println(DOLLAR_FORMAT.apply(0.0033).toString());
         System.out.println(DOLLAR_FORMAT.apply(0.0114).toString());
        
    Function<Double, String> billableMinsFmt = (Double d) -> {
        if (d == null) {
            return " 00000000.00";
        }
        DecimalFormat df = new DecimalFormat("#.00");         
        if (d > 0) {
            String formated = df.format(d);
            return " " + StringUtils.leftPad(formated, 11, "0");
        }
        else if (d < 0) {
            String formated = df.format(Math.abs(d));
            return "-" + StringUtils.leftPad(formated, 11, "0");
        }
        else return " 00000000.00";
    }; 
    System.out.println();
    System.out.println(billableMinsFmt.apply(0.0114).toString());
    System.out.println(billableMinsFmt.apply(0.2514).toString());
    System.out.println(billableMinsFmt.apply(0.2954).toString());
    System.out.println(billableMinsFmt.apply(0.2954).toString());
    System.out.println(billableMinsFmt.apply(0.0).toString());
    System.out.println(billableMinsFmt.apply(-0.0014).toString());
    System.out.println(nonInternational.test("CA"));
    System.out.println(nonInternational.test("US"));
    System.out.println(nonInternational.test(null));
    
     for (TrafficLight light : TrafficLight.values()) {
         System.out.printf("%s: %d seconds\n", light, light.getSeconds());
      }
     
     Child1 c1 = new Child1();
     Child2 c2 = new Child2();
     tester.process(c1);
     tester.process(c2);
     
     String ori="I am MISS1 PUNT1 ok pU2nt mother1 punt1 punt1.";
     String regex = "\\b(ship)\\b|\\b(miss)\\b|\\b(duck)\\b|\\b(punt)\\b|\\b(rooster)\\b|\\b(mother)\\b|\\b(bits)\\b";
        Pattern pp = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
        System.out.println(pp.matcher(ori).find());
     String oo = " I ";
     System.out.println(Arrays.toString(oo.split("[' ]+")));
       
     System.out.println("1".substring(1));
    }

}
