/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1.trimap;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Stack;

/**
 *
 * @author Peng
 */
public class Amazon1 {

    private void caculateAndPrint(int[] al) {
        int[] diff = new int[al.length - 1];
        for (int i = 1; i < al.length; i++) {
            diff[i - 1] = al[i] - al[i - 1];

        }
        System.out.println(Arrays.toString(diff));
        List<Integer> subArray = new ArrayList();
        for (int i = 0; i < diff.length; i++) {
            if (diff[i] > 0 && (subArray.size() == 0 || subArray.get(subArray.size() - 1) > 0)) {
                if (subArray.size() == 0) {
                    System.out.println(i + 1);
                }
                subArray.add(diff[i]);
                if (i == diff.length - 1) {
                    System.out.println(i + 2);
                }
            }
            if (diff[i] <= 0) {
                if (subArray.size() > 0) {
                    System.out.println(i + 1);
                }
                subArray.clear();
            }
        }
    }

    public String pushAndPop(int[] original, int[] result, int length) {
//        String original = "1 2 3 4";
        String r = "";

        Stack<String> stack = new Stack();
        Stack<Integer> stack1 = new Stack();
        for (int k = length - 1; k >= 0; k--) {
            stack1.push(original[k]);
        }
        int idx = 1;
        int i = 0;
        while (i < length) {
            int current = result[i];
            if (!stack.empty() && Integer.valueOf(stack.peek().split(":")[0]) == current) {
                i++;
                r += "pop"+stack.pop().split(":")[1]+"|";
            } else if (!stack1.empty()) {
                stack.push(stack1.pop().toString()+":"+(idx));
                r += "push"+idx+"|";
                idx++;
            } else {
                r = "N/A";
                break;

            }
        }
        return r;

    }
    
    public void findMaxDifference(int[] original, int length) {
        if (length <= 1) {
            System.out.println("NO GAP"); 
            return;
        }
        int currentDiff = original[1] - original[0];
        int min = original[1] > original[0] ? original[0] : original[1];
        for (int i = 2; i < length; i++) {
            if (original[i] - min > currentDiff) {
                currentDiff = original[i] - min;
            }
            if (original[i] < min) {
                min = original[i];
            }
        }
        System.out.println("current max diff:" + currentDiff);
        
        
    }

    public static void main(String args[]) {
//        int[] al = new int[]{1,6,2,3,5,1,1,2,10,16};
//        int[] al = new int[]{1, 3, 5, 4, 2, 8, 10};
        int[] al = new int[]{1, 1, 1, 3, 5, 4, 2, 2, 2, 8, 10};
        System.out.println(Arrays.toString(al));
        Amazon1 amazon1 = new Amazon1();
        amazon1.caculateAndPrint(al);

//        String product = "item1";
//        String arrayStr = "custA item1 custB item1 custA item2 custB item3 custC item1 custC item3 custD item2";
        String product = "item2";
        String arrayStr = "custA item1 custB item1 custC item1 custA item2 custB item3 custA item3";
        String[] arr = arrayStr.split(" ");
        HashMap<String, ArrayList<String>> map = new HashMap();
        for (int i = 0; i < arr.length; i++) {
            if (i % 2 == 0) {
                if (map.get(arr[i]) == null) {
                    map.put(arr[i], new ArrayList());
                }
            } else {
                map.get(arr[i - 1]).add(arr[i]);
            }
        }
        System.out.println(map.toString());
        HashMap<String, Integer> result = new HashMap();
        int max = 0;
        map.forEach((cust, products) -> {
            if (products.contains(product)) {
                products.stream().filter(str -> !str.equals(product)).forEach(t -> {
                    if (result.get(t) == null) {
                        result.put(t, 1);
                    } else {
                        result.put(t, result.get(t) + 1);
                    }
                });
            }
        });
        System.out.println(result.toString());
        String resultPro = "NONE";
        if (result.isEmpty()) {
            System.out.println(resultPro);
        } else {
            max = result.values().stream().max((t1, t2) -> t1 - t2).get();
            System.out.println(
                    result.entrySet().stream().max((t1, t2) -> t1.getValue() - t2.getValue()).get().getKey()
            );
        }

//        String r = amazon1.pushAndPop(new int[]{1, 2, 3, 4}, new int[]{1, 2, 3, 4}, 4);
        String r = amazon1.pushAndPop(new int[]{1, 2, 3, 4,8}, new int[]{ 4,8,3,2,1}, 5);
//        String r = amazon1.pushAndPop(new int[]{1, 2, 3, 4}, new int[]{ 3,1,2,4}, 4);
//        String r = amazon1.pushAndPop(new int[]{1, 2, 3}, new int[]{1, 3, 2}, 3);
        System.out.println(r);
        
        amazon1.findMaxDifference(new int[]{4,8,3,18,21}, 5);

    }

}
