/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1.trimap;

import java.util.ArrayList;
import static java.util.Collections.list;
import java.util.List;

/**
 *
 * @author Peng
 */
public class StringIfChained {
    boolean chained(String s1, String s2) {
        if (s2 == null) return false;
        if (s1.substring(0,1).equals(s2.substring(s2.length()-1, s2.length())) ) {
            return true;
        }
        else return false;
    }
    
    boolean run(List<String> list, String current) {
        if (current == null) {
            boolean r = false;
            for (int i = 0; i < list.size(); i++) {
                List<String> newlist = new ArrayList();
                newlist.addAll(list);
                newlist.remove(i);
                r = run(newlist, list.get(i));
                if (r) {
                    break;
                }
            }
            return r;
        }
        else if (list.size() == 1  ) {
            if (chained(list.get(0), current))
            return true;
            else return false;
        }
        else {
            int j = 0;
            for (j = 0; j < list.size(); j++) {
                if (chained(list.get(j), current)) {
                    String s = list.get(j);
                    list.remove(j);
                    return run (list, s);
                }
            }
            return false;
        }   
    }
    
    public static void main(String[] args) {
        List<String> list = new ArrayList(); 
        list.add("bc");
        list.add("ab");
        list.add("df");
        list.add("fasdfasdg");
        list.add("cd");
        StringIfChained sc = new StringIfChained();
        boolean r = sc.run(list, null);
        System.out.println(r);
        
    }
    
    
}
