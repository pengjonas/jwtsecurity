/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1.sn;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import static java.util.stream.Collectors.toList;

/**
 *
 * @author Peng
 */
public class FindTwoLevelFriends {
    public List<User> find2LevelFriends(User user) {
        List<User> twoLevelFriends = new ArrayList();
        int j = 1;
        user.getFriends().forEach(new Consumer<User>() {
            @Override
            public void accept(User firstLevel) {
               
                twoLevelFriends.addAll(firstLevel.getFriends());
            }
        });
        Predicate<User> predicate = t -> !user.getFriends().contains(t);
        return twoLevelFriends.stream().filter(predicate).distinct().collect(toList());
        
    }
    
    
    public static void main(String args[]) {
        User user1 = new User(1, "J1", "P1");
        User user2 = new User(2, "J2", "P2");
        User user3 = new User(3, "J3", "P3");
        User user4 = new User(4, "J4", "P4");
        User user5 = new User(5, "J5", "P5");
        User user6 = new User(6, "J6", "P6");
        User user7 = new User(7, "J7", "P7");
        User user8 = new User(8, "J8", "P8");
        User user9 = new User(9, "J9", "P9");
        user1.addFriend(user2);
        user1.addFriend(user3);
        user1.addFriend(user4);
        user1.addFriend(user5);
        user1.addFriend(user6);
        user1.addFriend(user7);
        user2.addFriend(user6);
        user3.addFriend(user7);
        user4.addFriend(user9);
        user5.addFriend(user8);
        user5.addFriend(user9);
        FindTwoLevelFriends findTwoLevelFriends = new FindTwoLevelFriends();
        List<String> s = findTwoLevelFriends.find2LevelFriends(user1).stream().map(user -> user.getFistName()+" "+user.getLastName()).collect(toList());
        s.forEach(t->System.out.println(t));
        
        
    }
}
