/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1.trimap;

/**
 *
 * @author Peng
 */
public class SychronizedTest {

    private  int common = 1;

    public synchronized void increaseCommon() {
        common++;
        System.out.println("" + common);
    }

    public synchronized int getCommon() {
//        int i = 1;
//        if (SychronizedTest.common / 2 == 0) {
//            System.out.println("J1: " + SychronizedTest.common);
//            i++;
//        }
//        if (SychronizedTest.common / 2 == 1) {
//            System.out.println("J2: " +SychronizedTest.common);
//            i--;
//        }
        common = 2;
        for(int i = 0; i< 100000;i++) {
            int j = 5*5;
        }
        return common;
    }

    public static void main(String args[]) {
        SychronizedTest st = new SychronizedTest();
        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    st.increaseCommon();
                    
                }

            }
        });
        Thread t2 = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                        System.out.println("adsf: " + st.getCommon());                        
                   
                }

            }
        });
        t1.start();
        t2.start();
    }
    

}
