/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import static java.util.stream.Collectors.groupingBy;
import org.apache.commons.lang.StringUtils;

/**
 *
 * @author Peng
 */
public class Java8Test2 {
    private List<Transaction> transactions;

    public Java8Test2() {
        this.init();
    }

    protected void init() {
        Trader raoul = new Trader("Raoul", "Cambridge");
        Trader mario = new Trader("Mario", "Milan");
        Trader alan = new Trader("Alan", "Cambridge");
        Trader brian = new Trader("Brian", "Cambridge");
        Long reviewId = null;
        String s = "Review " + ((reviewId != null) ? reviewId.toString() : "") + " cannot be saved!";
        this.transactions = Arrays.asList(
                new Transaction(brian, 2011, 300),
                new Transaction(raoul, 2012, 1000),
                new Transaction(raoul, 2011, 400),
                new Transaction(mario, 2012, 710),
                new Transaction(mario, 2012, 700),
                new Transaction(alan, 2012, 950)
        );
    }
    public static void  main(String args[]) {
        
        
        Java8Test2 test = new Java8Test2();
        System.out.println("test");
        DecimalFormat df = new DecimalFormat("#.##");
        System.out.println(df.format(-0.00123));
        System.out.println(df.format(2.03532));
        System.out.println(df.format(-22.05932));
        String s = "df";
                String regex = "\\b(ship)\\b|\\b(miss)\\b|\\b(duck)\\b|\\b(punt)\\b|\\b(rooster)\\b|\\b(mother)\\b|\\b(bits)\\b";
        Pattern p = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
        Long d=2L;
        d.toString()
        HashMap<String, List<Transaction>> hashMap = new HashMap<>();
        test.transactions.stream().map(
                t -> { 
                    if (hashMap.get(t.getTrader().getName()) == null)
                        hashMap.put(t.getTrader().getName(), new ArrayList<Transaction>()); 
                    hashMap.get(t.getTrader().getName()).add(t);
                    return hashMap.get(t.getTrader().getName());
                }
        ).forEach(list->System.out.println(list.size()));
        
       test.transactions.stream().collect(groupingBy((Transaction t)->t.getTrader())).keySet().forEach(trader-> System.out.println(trader));
       System.out.println(test.transactions.stream().collect(Collectors.counting()));
       System.out.println(
               test.transactions.stream().collect(
                       Collectors.minBy(
                               (Transaction t1, Transaction t2)->Integer.compare(t1.getValue(), t2.getValue())
                       )
               )
       );
       test.transactions.sort((Transaction t1, Transaction t2)->Integer.compare(t1.getValue(), t2.getValue()));
       test.transactions.stream().forEach(t->System.out.println(t.getValue()+"g"));
       System.out.println("0005234".compareTo("0002345"));
       System.out.println("jonas"+Runtime.getRuntime().availableProcessors());
        Comparator<Transaction> comparator = Comparator.comparing(Transaction::getValue);
       test.transactions.stream().max(comparator);
       List<Integer> list = Arrays.asList(1,4,9,5);
       test.getSubSet(list);
       StringUtils.isEmpty("g");
    }
    protected void getSubSet(List<Integer> list) {
        list.stream().forEach(i -> {
            List<Integer> subSet = list.stream().filter(j-> j != i).collect(Collectors.toList());
            subSet.stream().forEach(k -> System.out.print(k));
            System.out.println();
            getSubSet(subSet);
                    }
        );
    }
    
}
