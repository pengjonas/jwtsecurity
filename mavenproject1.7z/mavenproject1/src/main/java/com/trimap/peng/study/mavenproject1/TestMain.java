/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1;

/**
 *
 * @author Peng
 */
public class TestMain {
    
    public static void main(String args[]) {
        Child1 child11 = new Child11();
        child11.go2();
        Child1 child1 = new Child1();
        child1.go1();
    }
    
}
