/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1;

import com.google.common.collect.HashBiMap;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Jonas Peng <jonas@trimap.com>
 */
public class GenericTypeStudy {


    public GenericTypeStudy() {

    }

  


    
    private static class MapFactory<K, V> {
        Map map;
        public MapFactory() {
            map = new HashMap();
        }
        
        private <K, V> Map<K, V> createMapFactory(K k, V v) {        
            map.put(k, v);
            return map;
        }
    }
    
    public static void main(String args[]) {
        MapFactory g = new MapFactory();
        System.out.println(g.createMapFactory("2", 2).keySet().iterator().next());
        System.out.println(g.createMapFactory(2, "2").keySet().iterator().next());

    }    

}
