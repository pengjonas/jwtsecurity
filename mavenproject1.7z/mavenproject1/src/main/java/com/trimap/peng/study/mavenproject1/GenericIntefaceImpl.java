/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1;

import java.util.function.Function;

/**
 *
 * @author Peng
 */
public class GenericIntefaceImpl implements GenericInteface<Child1> {

    @Override
    public Child1 get() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Child1 assume(Child1 t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void process(SubGenericInteface<? super Child1, ? extends Child1> gi) {
        Parent c = gi.process(new Child11());
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }









}
