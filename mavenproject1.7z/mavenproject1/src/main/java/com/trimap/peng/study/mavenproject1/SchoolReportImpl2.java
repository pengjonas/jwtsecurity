/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1;

/**
 *
 * @author Peng
 */
public class SchoolReportImpl2 extends SchoolReportDecorator {
    
    public SchoolReportImpl2(SchoolReportImpl schoolReport) {
        super(schoolReport);
    }
    
    @Override
    public void report() {
        super.report();
        //something else;
    }
    
    @Override
    public void sign() {
        super.sign();
        //something else;
    }
    
    
}
