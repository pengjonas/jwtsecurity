/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1;

/**
 *
 * @author Jonas Peng <jonas@trimap.com>
 */
public class Child1 extends Parent {

    private String s="";
    Child1() {
        s = "ok";
    }

    @Override
    public void go() {
        System.out.print("child1");
    }
    
    public void go1() {
        System.out.print("child1 g1");
    }
    
}
