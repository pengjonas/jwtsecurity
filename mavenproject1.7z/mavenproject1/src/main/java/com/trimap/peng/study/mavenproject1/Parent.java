/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1;

/**
 *
 * @author Jonas Peng <jonas@trimap.com>
 */
public abstract class Parent implements ParentInterface {
    public abstract void go();
    public void go2() {
        System.out.println("go2 in parent");
    };
    public void go1() {
        System.out.println("go1 in parent");
    };
    
    
}
