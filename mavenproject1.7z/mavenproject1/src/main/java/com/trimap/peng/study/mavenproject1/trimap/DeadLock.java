/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1.trimap;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Peng
 */
public class DeadLock   {

    final Logger logger = Logger.getLogger(getClass().getName());

    public synchronized void check() {
        
    }
    public synchronized void run(DeadLock other) {
        try {
            Thread.sleep(150);
        } catch (InterruptedException ex) {
            Logger.getLogger(DeadLock.class.getName()).log(Level.SEVERE, null, ex);
        }
        other.check();
    }   

    public static void main(String args[]) {
        DeadLock d1 = new DeadLock();
        DeadLock d2 = new DeadLock();
        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                d1.run(d2); //To change body of generated methods, choose Tools | Templates.
            }
        });
        Thread t2 = new Thread(new Runnable() {
            @Override
            public void run() {
                d2.run(d1); //To change body of generated methods, choose Tools | Templates.
            }
        });
        t1.start();
        t2.start();

    }

}
