/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import static java.util.Comparator.comparing;
import java.util.List;
import java.util.function.BiPredicate;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.function.IntToDoubleFunction;
import java.util.function.Predicate;
import static java.util.stream.Collectors.toList;
import org.apache.commons.lang.StringUtils;

/**
 *
 * @author Peng
 */
public class Java8Tester {
   public static void main(String args[]){
      Java8Tester tester = new Java8Tester();
		
      //with type declaration
      MathOperation addition = new MathOperation() {
          @Override
          public int operation(int a, int b) {
              return a + b;
          }
      };
      
      Function<Integer, Integer> plus1 = (Integer a) -> a + 1;
      
      Predicate<Integer> positive = (Integer a) -> a > 0;
      
      Comparator<Integer> comparator = (Integer o1, Integer o2) -> 0;
      Comparator<Long> comparator1 = (Long o1, Long o2) -> 0;
      
      Thread t = new Thread(() -> {
          System.out.println("Hello world");
      });
      Predicate<List<String>> p = (List<String> list) -> list.isEmpty();
      Runnable runnable = () -> {
          new Exception ("d");
      };
      Function<String, Integer> f = new Function<String, Integer>() {
          @Override
          public Integer apply(String s) {
              return s.length();
          }
      };
      Function<String, Integer>  f1 = (String s) -> s.length();
      Function<String, Integer>  f12 = String::length;
      List<String> array = Arrays.asList("ab", "bbb", "cddd", "dddfdf");array.stream().collect(toList());
      
      array.sort(comparing((string) -> string.toString()));
      
      BiPredicate<List<String>, String> contains = (list, element) -> list.contains(element);
      BiPredicate<List<String>, String> contains1 = List::contains; // (list, element) -> list.contains(element);
      
      Function<String, Integer> supplier = Integer::new;
      supplier.apply("2");
              
      List<Integer> l1 = Arrays.asList(1,2,3,4);
      l1.stream().filter(i -> i > 5).findAny().ifPresent(i->System.out.println(i.toString()));
      
      BinaryOperator<Integer> bo = (i1, i2) -> i1>i2?i1:i2;
      l1.stream().reduce(bo);
      l1.stream().reduce(Integer::max);
      
      List<Integer> l2 = Arrays.asList(5,6);
      List<Integer> l = l1.stream().map(i->i*i).collect(toList());
      List<int[]> l3 = l1.stream().flatMap(i -> l2.stream().map(j -> new int[]{i, j})).collect(toList());
      System.out.println("Jonas: " + Arrays.toString(l3.get(0)));
      
      //with out type declaration
      MathOperation subtraction = (a, b) -> a - b;
		
      //with return statement along with curly braces
      String s = "";
      MathOperation multiplication = (int a, int b) -> {System.out.println(s); return a * b; };
		
      //without return statement and without curly braces
      MathOperation division = new MathOperation() {
          @Override
          public int operation(int a, int b) {
              return a / b;
          }
      };
      
      IntToDoubleFunction f2 = (int a) -> 0D;
		
      System.out.println("10 + 5 = " + tester.operate(10, 5, addition));
      System.out.println("10 - 5 = " + tester.operate(10, 5, subtraction));
      System.out.println("10 x 5 = " + tester.operate(10, 5, multiplication));
      System.out.println("10 / 5 = " + tester.operate(10, 5, division));
      System.out.println("10 + 1 = " + plus1.apply(10));
      System.out.println("Postive in [0,1,2,3 -2,-4]: " + (tester.filter(Arrays.asList(0,1,2,3 -2,-4), positive).toString()));
      int[] a = new int[3];
      
      
		
      //with parenthesis
      GreetingService greetService1 = message ->
      System.out.println("Hello " + message);
     
		
      //without parenthesis
      GreetingService greetService2 = (message) ->
      System.out.println("Hello " + message);
		
      greetService1.sayMessage("Mahesh");
      greetService2.sayMessage("Suresh");
      
      System.out.println(String.format("%04d", 300));
      System.out.println(String.format("%04d", 54312));
      String s1 = String.format("%.2f%n", 0.9).toString();
      double dd = 2.0;
      int integral = (int)dd;
      int i2 = (int)(dd*100);
      int fragment = i2 - integral*100;
      System.out.println(StringUtils.leftPad(String.valueOf(integral), 8, "0") + "." + StringUtils.rightPad(String.valueOf(fragment), 2, "0"));
//      System.out.println(StringUtils.leftPad(dd.toString(), 0));
//      System.out.println(dd.toString().split(".")[1]);

    String test = null;
    if (test != null && test.endsWith("d")) {
        
    }else {
        System.out.println("ok");
    }
      
    System.out.println(10.25 + 10.25*17/100 + 10.25*5/100);
   }
	
   interface MathOperation {
      int operation(int a, int b);
   }
	
   interface GreetingService {
      void sayMessage(String message);
   }
	
   private int operate(int a, int b, MathOperation mathOperation){
      return mathOperation.operation(a, b);
   }
   
   private <T> List<T> filter(List<T> list, Predicate<T> p) {
       ArrayList result = new ArrayList();
       for (T t : list) {
           if (p.test(t)) {
               result.add(t);
           }
       }
       return result;
               
   }
}

