/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trimap.peng.study.mavenproject1.trimap;

import java.util.LinkedList;

/**
 *
 * @author Peng
 */
public class MyLinkedList {
    private LinkedList<String> linkedList = null;

    public MyLinkedList() {
        linkedList = new LinkedList<>();
        linkedList.add("s");
    }
    
    
    
}
